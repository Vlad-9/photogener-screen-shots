#!/bin/bash
set -euo pipefail

BASE="${PHOTO_TOOLS_BASE:-https://photopea.fun}"
KEY="${PHOTO_TOOLS_KEY:-d6215f2763806eaf6e433191841c68e4aa0e52a4407a6d89}"
WORKDIR="${TMPDIR:-/tmp}/photo-tools-test"
mkdir -p "$WORKDIR"

say() { printf '\n%s\n' "$*"; }

pick_image() {
  if [[ -n "${PHOTO_TOOLS_IMAGE:-}" && -f "$PHOTO_TOOLS_IMAGE" ]]; then
    printf '%s' "$PHOTO_TOOLS_IMAGE"
    return
  fi
  local picked
  picked="$(osascript <<'APPLESCRIPT' 2>/dev/null || true
try
  set theFile to choose file with prompt "Выбери фото для теста API" of type {"public.image", "public.jpeg", "public.png"}
  POSIX path of theFile
on error
  ""
end try
APPLESCRIPT
)"
  picked="${picked%"${picked##*[![:space:]]}"}"
  if [[ -n "$picked" && -f "$picked" ]]; then
    printf '%s' "$picked"
    return
  fi
  local fallback="$WORKDIR/live.jpg"
  say "Файл не выбран — качаю тестовое фото…"
  curl -sSL -o "$fallback" \
    'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=1200&q=80'
  printf '%s' "$fallback"
}

http_post_tool() {
  local tool="$1"; shift
  local img="$1"; shift
  local out="$WORKDIR/${tool}.json"
  local hdr="$WORKDIR/${tool}.hdr"
  say "POST $BASE/api/photo-tools/$tool"
  say "image: $img"
  curl -sS -D "$hdr" -o "$out" \
    -H 'Accept: application/json' \
    -H "X-API-Key: $KEY" \
    -F "image=@${img}" \
    "$@" \
    "$BASE/api/photo-tools/$tool" || true
  echo "---- headers ----"
  cat "$hdr"
  echo "---- body ----"
  cat "$out"
  echo
}

poll_task() {
  local json="$1"
  local task
  task="$(python3 -c 'import json,sys; from pathlib import Path; p=Path(sys.argv[1]);
print((json.loads(p.read_text() or "{}") if p.exists() and p.stat().st_size else {}).get("task_id") or "")' "$json")"
  if [[ -z "$task" ]]; then
    say "task_id нет — поллинг не запускаю. Если 404, роута на сервере ещё нет."
    return 1
  fi
  say "poll task_id=$task каждые 4 с"
  local i
  for i in $(seq 1 45); do
    curl -sS -o "$WORKDIR/status.json" \
      -H 'Accept: application/json' \
      -H "X-API-Key: $KEY" \
      "$BASE/api/photo-tools/$task" || true
    python3 -c 'import json,sys; print(json.dumps(json.load(open(sys.argv[1])), ensure_ascii=False, indent=2))' "$WORKDIR/status.json"
    local state url
    state="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("state") or "")' "$WORKDIR/status.json")"
    url="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("url") or "")' "$WORKDIR/status.json")"
    if [[ "$state" == "success" && -n "$url" ]]; then
      local dest="$WORKDIR/result-${task}.png"
      say "скачиваю $url → $dest"
      curl -sSL -o "$dest" "$url"
      open "$dest" || true
      return 0
    fi
    if [[ "$state" == "fail" || "$state" == "error" ]]; then
      say "задача упала"
      return 1
    fi
    sleep 4
  done
  say "таймаут ожидания"
  return 1
}

img="$(pick_image)"
say "фото: $img"

say "контроль /moderate"
curl -sS -D - -o "$WORKDIR/moderate.json" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: $KEY" \
  -d '{"prompt":"a cat"}' \
  "$BASE/moderate" || true
echo; cat "$WORKDIR/moderate.json"; echo

http_post_tool enhance "$img"
http_post_tool upscale "$img" -F 'factor=2'
http_post_tool remove-background "$img"
http_post_tool remove-object "$img" -F 'object=the person'
http_post_tool replace-object "$img" -F 'object=the ice crown' -F 'replacement=a golden crown'

say "поллинг enhance, если был task_id"
poll_task "$WORKDIR/enhance.json" || true

echo
read -r -p "Готово. Нажми Enter… "
