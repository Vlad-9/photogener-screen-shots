Тест API photo-tools (photopea.fun)

На iPhone этот скрипт не запускается. Скачай zip, перешли на Mac.

На Mac:
1. Распакуй архив
2. Двойной клик по test-photo-tools.command
   или в Терминале:
   chmod +x test-photo-tools.sh
   ./test-photo-tools.sh

Скрипт спросит фото, проверит /moderate и все методы /api/photo-tools/*.
